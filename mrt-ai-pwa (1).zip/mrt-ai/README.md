# MRT AI (BLC)

Kurulabilir web uygulaması (PWA) + FastAPI sunucusu. Sohbet geçmişi kullanıcının cihazında saklanır.

## Yerelde çalıştırma
1. `pip install -r requirements.txt`
2. `export ANTHROPIC_API_KEY=anahtariniz` (isteğe bağlı: `export ACCESS_CODE=gizli-kod`)
3. `uvicorn server:app --reload` ve `http://localhost:8000` adresini açın.

## Yayına alma (telefona kurulum için HTTPS şart)
Render, Railway, Fly.io gibi bir platformda bu klasörü (Dockerfile ile) yayınlayın.
Ortam değişkenleri: `ANTHROPIC_API_KEY` (zorunlu), `ACCESS_CODE` (önerilir), `MRT_MODEL` (isteğe bağlı).
`ACCESS_CODE` koymazsanız adresi bilen herkes API anahtarınızın kredisini harcayabilir.

## Telefona kurma
- Android/Chrome: menüden "Uygulamayı yükle" ya da "Ana ekrana ekle".
- iPhone/Safari: Paylaş > "Ana Ekrana Ekle".

## Google'da görünme
1. Siteyi kendi alan adınızla yayınlayın, ardından search.google.com/search-console'a ekleyin.
2. "URL inceleme" ile ana sayfayı dizine eklenmesi için gönderin.
3. Alan adınız belli olunca `static/robots.txt` dosyasına `Sitemap: https://alanadiniz.com/sitemap.xml` satırı ve bir sitemap.xml ekleyebilirsiniz.
