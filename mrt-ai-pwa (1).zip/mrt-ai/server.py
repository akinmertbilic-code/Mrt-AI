import hmac
import os

from anthropic import AsyncAnthropic
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles

SYSTEM = (
    "Sen MRT AI'sin: sıcak, samimi ve pratik bir günlük yaşam danışmanısın. "
    "Kullanıcıyla sohbet et; günlük hayat, ilişkiler, iş-okul, alışkanlıklar, para yönetimi, "
    "sağlıklı yaşam, seyahat ve yemek gibi konularda net, uygulanabilir tavsiyeler ver. "
    "Kullanıcının yazdığı dilde (varsayılan Türkçe) ve kısa, anlaşılır cevap ver; gerekirse tek bir açıklayıcı soru sor. "
    "Tıbbi, hukuki ve finansal konularda genel bilgi ver, gerektiğinde uzmana yönlendir. "
    "Ciddi bir kriz ya da kendine zarar belirtisi görürsen şefkatle yaklaş ve yerel acil yardım hatlarına "
    "ya da güvendiği birine ulaşmasını öner."
)
MODEL = os.getenv("MRT_MODEL", "claude-sonnet-5-5")
ACCESS_CODE = os.getenv("ACCESS_CODE", "")
client = AsyncAnthropic()  # ANTHROPIC_API_KEY ortam değişkenini okur
app = FastAPI()


@app.post("/api/chat")
async def chat(req: Request):
    if ACCESS_CODE and not hmac.compare_digest(req.headers.get("x-access-code", ""), ACCESS_CODE):
        raise HTTPException(status_code=401)
    body = await req.json()
    msgs = [
        {"role": m["role"], "content": str(m.get("content", ""))[:4000]}
        for m in body.get("messages", [])[-20:]
        if m.get("role") in ("user", "assistant") and str(m.get("content", "")).strip()
    ]
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    if not msgs or msgs[-1]["role"] != "user":
        raise HTTPException(status_code=400)

    async def gen():
        try:
            async with client.messages.stream(model=MODEL, max_tokens=1000, system=SYSTEM, messages=msgs) as s:
                async for t in s.text_stream:
                    yield t
        except Exception:
            yield "\n\n(Bağlantı hatası, lütfen tekrar deneyin.)"

    return StreamingResponse(gen(), media_type="text/plain; charset=utf-8",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


app.mount("/", StaticFiles(directory="static", html=True), name="static")
